package com.pimatech.balldrop.engine

import org.junit.Assert.*
import org.junit.Test
import kotlin.math.*

class BallDropTest {
    private val base=Geometry(.4,.3605,60.0,.4375)
    private fun near(a:Double,b:Double,eps:Double=1e-12)=assertEquals(a,b,eps)
    @Test fun referenceAndIndependentGeometry() {
        val cone=BallDrop.cone(base)
        near(.43907487971871034,cone.optimalBall)
        val c=BallDrop.contact(base.copy(ball=cone.optimalBall))
        near(.38025,c.diameter); near(50.0,c.percent)
        // Independent construction: center-to-wall perpendicular distance is R.
        val r=base.ball/2; val apex=base.major/(2*tan(cone.theta))
        val zCenter=r/sin(cone.theta)-apex
        val tangentZ=zCenter-r*sin(cone.theta)
        val tangentX=r*cos(cone.theta)
        near(tangentX,base.major/2+tangentZ*tan(cone.theta))
        near(r,sqrt((tangentZ-zCenter).pow(2)+tangentX.pow(2)))
        near(zCenter+r,BallDrop.contact(base).height)
        near(.3788861141556919,BallDrop.contact(base).diameter)
        near(.3098398384862245,BallDrop.contact(base).height)
    }
    @Test fun strictEdgesAndBothSides() {
        val c=BallDrop.cone(base)
        for(b in listOf(c.minimumBall,c.maximumBall,c.minimumBall*.9,c.maximumBall*1.1)) assertFalse(BallDrop.validContact(base.copy(ball=b)))
        assertTrue(base.ball>base.major); assertTrue(BallDrop.validContact(base))
    }
    @Test fun roundTripsAcrossAnglesAndUnits() {
        for(a in listOf(.001,1.0,30.0,60.0,82.0,90.0,100.0,120.0,179.999)) {
            val g=base.copy(angle=a,ball=BallDrop.cone(.4,.3605,a).optimalBall)
            val p=BallDrop.contact(g).height
            // Near 180°, reverse conditioning amplifies one height ULP.
            val numericalBound=maxOf(1e-10,8*Math.ulp(maxOf(g.ball,abs(p)))/cos(Math.toRadians(a/2)))
            near(g.major,BallDrop.actualMajor(g.ball,a,p),numericalBound)
            val metric=g.copy(major=g.major*25.4,minor=g.minor*25.4,ball=g.ball*25.4)
            near(p*25.4,BallDrop.contact(metric).height,1e-6)
        }
        near(.4375,LengthUnit.MM.canonical(11.1125)); near(11.1125,LengthUnit.MM.display(.4375))
    }
    @Test fun invalidInputs() {
        for(g in listOf(base.copy(major=0.0),base.copy(minor=-1.0),base.copy(ball=0.0),base.copy(ball=Double.NaN),base.copy(major=.36),base.copy(major=.3605),base.copy(angle=0.0),base.copy(angle=180.0),base.copy(angle=-60.0),base.copy(angle=Double.POSITIVE_INFINITY))) {
            assertFalse(BallDrop.validContact(g)); assertEquals(InspectionStatus.INVALID,BallDrop.inspect(g,.3,Tolerance(.001,.001)).status)
        }
    }
    @Test fun toleranceAndMeasurementStates() {
        val t=Tolerance(.002,.003); val band=BallDrop.band(base,t)
        assertTrue(band.validThroughout)
        for(d in listOf(.398,.4,.403)) {
            val p=BallDrop.contact(base.copy(major=d)).height
            assertEquals(InspectionStatus.PASS,BallDrop.inspect(base,p,t).status)
        }
        for(d in listOf(.3979,.4031)) assertEquals(InspectionStatus.FAIL,BallDrop.inspect(base,BallDrop.contact(base.copy(major=d)).height,t).status)
        near(BallDrop.contact(base.copy(major=.403)).height,band.minimumHeight)
        near(BallDrop.contact(base.copy(major=.398)).height,band.maximumHeight)
        assertEquals(InspectionStatus.NOT_EVALUATED,BallDrop.inspect(base,null,t).status)
        assertEquals(InspectionStatus.NOT_EVALUATED,BallDrop.inspect(base,.31,null).status)
        assertEquals(InspectionStatus.INVALID,BallDrop.inspect(base,1.0,t).status)
        assertEquals(InspectionStatus.INVALID,BallDrop.inspect(base,Double.NaN,t).status)
        assertEquals(InspectionStatus.INVALID,BallDrop.inspect(base,.31,Tolerance(-.001,.001)).status)
        assertFalse(BallDrop.band(base,Tolerance(.03,.001)).validThroughout)
    }
    @Test fun measuredValidityDoesNotUseNominalContact() {
        val g=base.copy(major=.37) // ball cannot seat in this nominal countersink
        assertFalse(BallDrop.validContact(g))
        assertEquals(InspectionStatus.FAIL,BallDrop.inspect(g,BallDrop.contact(base).height,Tolerance(.001,.001)).status)
        val edgeHeight=base.ball/2*(1+1/sin(Math.PI/6))-BallDrop.contactDiameter(base.ball,60.0)/(2*tan(Math.PI/6))
        assertEquals(InspectionStatus.INVALID,BallDrop.inspect(base,edgeHeight,null).status)
    }
    @Test fun selectionFiltersAndRanks() {
        val ideal=BallDrop.cone(base).optimalBall
        val ranked=BallSelection.rank(base,listOf(BallSize("bad",.1),BallSize("ideal",ideal),BallSize("7/16",.4375),BallSize("big",1.0)))
        assertEquals(listOf("ideal","7/16"),ranked.map{it.size.label})
        assertTrue(BallSelection.fractional.any{it.label=="7/16 in" && it.inches==.4375})
    }
    @Test fun randomizedIndependentDistanceAndReverse() {
        val random=java.util.Random(90210)
        repeat(1000) {
            val d=.01+random.nextDouble()*2; val D=d+.001+random.nextDouble()
            val a=10+random.nextDouble()*160; val theta=Math.toRadians(a/2)
            val c=d+(D-d)*(.01+.98*random.nextDouble()); val b=c/cos(theta)
            val g=Geometry(D,d,a,b); val result=BallDrop.contact(g)
            val center=result.height-b/2
            val wallIntercept=D/2
            val distance=abs(-center*tan(theta)-wallIntercept)/sqrt(1+tan(theta).pow(2))
            near(b/2,distance,1e-10)
            near(D,BallDrop.actualMajor(b,a,result.height),1e-10)
        }
    }
    @Test fun shallowConeAndSectionCoordinates() {
        val g=base.copy(minor=.399999,angle=179.0,ball=BallDrop.cone(.4,.399999,179.0).optimalBall)
        val c=BallDrop.contact(g); val section=Section.of(g)
        assertTrue(section.depth>0 && section.depth<1e-8)
        near(50.0,c.percent,1e-6)
        near(section.contactRadius!!,g.major/2+section.contactZ!!*tan(Math.toRadians(g.angle/2)),1e-9)
        near(g.major,BallDrop.actualMajor(g.ball,g.angle,c.height),1e-10)
        assertNull(Section.of(base.copy(ball=.1)).ballCenterZ)
        assertEquals(InspectionStatus.PASS,BallDrop.inspect(base,BallDrop.contact(base).height,Tolerance(0.0,0.0)).status)
    }

}
