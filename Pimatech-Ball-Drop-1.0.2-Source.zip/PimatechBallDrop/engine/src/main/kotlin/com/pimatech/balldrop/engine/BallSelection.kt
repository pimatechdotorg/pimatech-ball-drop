package com.pimatech.balldrop.engine

import kotlin.math.abs

data class BallSize(val label: String,val inches: Double)
data class RankedBall(val size: BallSize,val contactPercent: Double)
object BallSelection {
    // Reference grids only. No supplier availability or inventory is asserted.
    val fractional = (1..64).map { n ->
        fun gcd(a:Int,b:Int):Int = if(b==0) a else gcd(b,a%b)
        val divisor=gcd(n,64)
        BallSize(if(n==64) "1 in" else "${n/divisor}/${64/divisor} in",n/64.0)
    }
    val metric = listOf(1.0,1.5,2.0,2.5,3.0,3.5,4.0,4.5,5.0,5.5,6.0,6.5,7.0,7.5,8.0,8.5,9.0,9.5,10.0,11.0,12.0,12.5,13.0,14.0,15.0,16.0,18.0,20.0,22.0,25.0).map { BallSize("$it mm",it/25.4) }
    fun rank(g: Geometry, balls: List<BallSize>): List<RankedBall> = balls.mapNotNull { b ->
        runCatching { RankedBall(b,BallDrop.contact(g.copy(ball=b.inches)).percent) }.getOrNull()
    }.sortedBy { abs(it.contactPercent-50) }
}
