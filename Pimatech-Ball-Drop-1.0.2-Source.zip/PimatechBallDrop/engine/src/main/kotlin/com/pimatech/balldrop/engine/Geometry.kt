package com.pimatech.balldrop.engine

import kotlin.math.*

/** Lengths are canonical inches. No UI rounding enters these functions. */
data class Geometry(val major: Double, val minor: Double, val angle: Double, val ball: Double)
data class Tolerance(val lower: Double, val upper: Double)
enum class InspectionStatus { PASS, FAIL, INVALID, NOT_EVALUATED }
data class Cone(val theta: Double, val depth: Double, val optimalBall: Double, val minimumBall: Double, val maximumBall: Double)
data class Contact(val diameter: Double, val percent: Double, val height: Double)
data class Inspection(val status: InspectionStatus, val actualMajor: Double? = null, val delta: Double? = null, val reason: String, val actualContact: Contact? = null)
data class HeightBand(val lowDiameter: Double, val highDiameter: Double, val minimumHeight: Double, val maximumHeight: Double, val validThroughout: Boolean)

object BallDrop {
    // Only floating-point guard space, not a physical acceptance tolerance.
    private fun guard(vararg values: Double) = values.maxOf { abs(it) }.coerceAtLeast(1e-100) * 1e-12
    fun cone(major: Double, minor: Double, angle: Double): Cone {
        require(listOf(major, minor, angle).all { it.isFinite() }) { "All inputs must be finite" }
        require(major > 0 && minor > 0 && major > minor) { "Require major > minor > 0" }
        require(angle > 0 && angle < 180) { "Included angle must be between 0° and 180°" }
        require(major - minor > guard(major, minor)) { "Countersink wall is numerically unresolved" }
        val theta = Math.toRadians(angle / 2)
        val result = Cone(theta, (major-minor)/(2*tan(theta)), (major/2+minor/2)/cos(theta), minor/cos(theta), major/cos(theta))
        require(listOf(result.depth, result.optimalBall, result.minimumBall, result.maximumBall).all { it.isFinite() && it > 0 }) { "Geometry exceeds numerical range" }
        return result
    }
    fun cone(g: Geometry) = cone(g.major, g.minor, g.angle)
    fun contactDiameter(ball: Double, angle: Double): Double {
        require(ball.isFinite() && ball > 0) { "Ball diameter must be positive" }
        require(angle.isFinite() && angle > 0 && angle < 180) { "Invalid included angle" }
        return ball*cos(Math.toRadians(angle/2))
    }
    fun validContact(g: Geometry): Boolean = runCatching {
        cone(g)
        val c = contactDiameter(g.ball,g.angle)
        val epsilon = guard(g.major,g.minor,c)
        c-g.minor > epsilon && g.major-c > epsilon
    }.getOrDefault(false)
    /** Algebraically equivalent to R*(1+csc(theta))-D*cot(theta)/2;
     * this form reduces subtraction near 180° using (1-sin)/cos = cos/(1+sin). */
    private fun rawHeight(major: Double, ball: Double, theta: Double): Double =
        ball/2 + (ball-major*cos(theta))/(2*sin(theta))
    fun contact(g: Geometry): Contact {
        val cone = cone(g)
        require(validContact(g)) { "Ball tangency must lie strictly inside the conical wall" }
        val c = contactDiameter(g.ball,g.angle)
        val height = rawHeight(g.major,g.ball,cone.theta)
        require(height.isFinite()) { "Height exceeds numerical range" }
        return Contact(c,100*(c-g.minor)/(g.major-g.minor),height)
    }
    fun actualMajor(ball: Double, angle: Double, measuredHeight: Double): Double {
        contactDiameter(ball,angle)
        require(measuredHeight.isFinite()) { "Measurement must be finite" }
        val theta = Math.toRadians(angle/2)
        val d = (ball*(1+sin(theta))-2*measuredHeight*sin(theta))/cos(theta)
        require(d.isFinite()) { "Derived diameter exceeds numerical range" }
        return d
    }
    fun band(g: Geometry,t: Tolerance): HeightBand {
        val c=cone(g)
        require(t.lower.isFinite() && t.upper.isFinite() && t.lower >= 0 && t.upper >= 0) { "Tolerance offsets must be finite and nonnegative" }
        val lo=g.major-t.lower; val hi=g.major+t.upper
        cone(lo,g.minor,g.angle); cone(hi,g.minor,g.angle)
        contactDiameter(g.ball,g.angle)
        return HeightBand(lo,hi,rawHeight(hi,g.ball,c.theta),rawHeight(lo,g.ball,c.theta),validContact(g.copy(major=lo)) && validContact(g.copy(major=hi)))
    }
    fun inspect(g: Geometry, height: Double?, tolerance: Tolerance?): Inspection {
        try { cone(g); contactDiameter(g.ball,g.angle) } catch(e: IllegalArgumentException) { return Inspection(InspectionStatus.INVALID,reason=e.message ?: "Invalid input") }
        if(height==null) return Inspection(if(validContact(g)) InspectionStatus.NOT_EVALUATED else InspectionStatus.INVALID,reason=if(validContact(g)) "Enter measured ball height" else "Nominal contact is outside the conical wall")
        val actual = runCatching { actualMajor(g.ball,g.angle,height) }.getOrElse { return Inspection(InspectionStatus.INVALID,reason=it.message ?: "Invalid measurement") }
        val actualG=g.copy(major=actual)
        if(!validContact(actualG)) return Inspection(InspectionStatus.INVALID,reason="Measured geometry has no valid conical contact")
        val measuredContact=contact(actualG)
        if(tolerance==null) return Inspection(InspectionStatus.NOT_EVALUATED,actual,actual-g.major,"Set inspection tolerances",measuredContact)
        val band=runCatching { band(g,tolerance) }.getOrElse { return Inspection(InspectionStatus.INVALID,reason=it.message ?: "Invalid tolerance band") }
        val eps=guard(actual,band.lowDiameter,band.highDiameter)
        val pass = actual >= band.lowDiameter-eps && actual <= band.highDiameter+eps
        return Inspection(if(pass) InspectionStatus.PASS else InspectionStatus.FAIL,actual,actual-g.major,if(band.validThroughout) "Measured geometry valid" else "Valid here; ball does not cover full tolerance band",measuredContact)
    }
}

enum class LengthUnit(val label: String,val perInch: Double,val decimals: Int) {
    INCH("in",1.0,5), MM("mm",25.4,4);
    fun display(inches: Double) = inches*perInch
    fun canonical(value: Double) = value/perInch
}
