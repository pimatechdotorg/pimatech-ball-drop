package com.pimatech.balldrop.engine

import kotlin.math.*

data class Section(val majorRadius:Double,val minorRadius:Double,val depth:Double,val ballRadius:Double,val ballCenterZ:Double?,val contactRadius:Double?,val contactZ:Double?) {
    companion object {
        fun of(g:Geometry):Section {
            val cone=BallDrop.cone(g)
            require(g.ball.isFinite() && g.ball>0) { "Invalid ball" }
            val contact=runCatching{BallDrop.contact(g)}.getOrNull()
            val center=contact?.height?.minus(g.ball/2)
            return Section(g.major/2,g.minor/2,cone.depth,g.ball/2,center,contact?.diameter?.div(2),center?.minus(g.ball/2*sin(cone.theta)))
        }
    }
}
