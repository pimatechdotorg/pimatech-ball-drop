# Pimatech Ball Drop Calculator — 1.0.2

Native Kotlin / Jetpack Compose Android application. No network permissions, accounts, ads, analytics or subscriptions. Android 8.0 (API 26) or later; intended for phones and Xreal Beam Pro 2. Device validation status is recorded in docs/VALIDATION.md.

## Build

Install Android Studio, open this folder, use JDK 17, and install Android SDK Platform 35. Let Gradle synchronize. The project pins Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin/Compose compiler 2.0.21 and Compose BOM 2024.12.01. First build needs Internet to fetch dependencies; running the app is entirely offline.

Linux/macOS: `./gradlew :engine:test :app:assembleDebug`

Windows PowerShell: `.\gradlew.bat :engine:test :app:assembleDebug`

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

If no APK accompanies this package, source delivery alone does not establish an Android build. See VALIDATION.md for actual executed results. Debug APKs use a development signing key. A production distribution should use a retained, privately controlled release key; do not put it in this project.

## Version 1.0.2 changes

Main-screen input and matching entry-dialog labels are now C'sink Major Ø and C'sink included angle. This is a cosmetic-only update. Install over 1.0.1 normally using Android's Update option; the signing identity is the same and saved local data is retained.

## Version 1.0.1 changes

The main-screen nominal section now shows the same surface-to-ball-top P marker as the expanded section. Both markers, including ticks and the P letter, are green. The predicted-height label and value use that exact same green. No inspection math or tolerance colors changed.

## Install

If upgrading from the original 1.0.0 test APK: record your inputs and ball inventory, uninstall the old app, then install this APK. If you already run 1.0.1, simply update without uninstalling. The first build's development signing key was not preserved and cannot be reconstructed from its APK; this one-time reinstall clears local data. A backup of the new development key has now been saved separately so later test updates can retain this signing identity and install in place.


Transfer the APK to the phone, open it in Files, and allow that Files app to install unknown apps if Android requests it. Install, then open Pimatech Ball Drop. You may disable that Files permission afterward. USB alternative with Android platform tools: `adb install -r app-debug.apk`.

## Operator workflow

1. Select inches or millimeters in Settings. All stored dimensions convert without rounding; angles remain degrees.
2. Tap the nominal major diameter, assumed/measured minor diameter, included angle and gauge ball buttons. Enter values with the popup keypad. Confirm each value.
3. Check that conical contact is valid. Optimal Ball shows the exact midpoint ball and reference size choices. Reference sizes are not confirmed shop stock or a commercial catalog. Add only balls actually on hand to My balls; those are ranked closest to 50% contact.
4. Measure the top of the seated ball relative to the part surface, then enter Measured height. It is a signed value; use minus only for a recessed top measured by a suitable depth setup. The predicted height is a nominal setup aid, not a measured part result.
5. Set lower and upper tolerance offsets in Tolerances. For example, lower .002 and upper .003 means nominal -.002/+.003. Zero is a valid explicit tolerance. Inspect the full-band contact warning and allowable height range.
6. Read PASS/FAIL only after entering a real measurement and explicit tolerances. INVALID means the result must not be used. NOT EVALUATED means measurement or tolerances are missing.
7. Tap the drawing for a larger nominal section and measured contact details. Green points are theoretical wall contact. Invalid seating suppresses seated-ball geometry and normal prediction.

Main values persist on the device, including the last measurement. Clear measured height before checking a different part. Reset asks for confirmation, returns geometry to the validation example, and clears measurement/tolerances; units and your ball inventory are retained. Cancel/back/outside dismissals do not commit numeric or tolerance drafts.

## Measurement limits

This is an ideal-geometry calculator, not a calibrated measuring instrument. Verify ball diameter/grade, angle and hole size, part condition, measurement method and uncertainty for the inspection requirement. There is no angle-error, uncertainty, blended-edge, out-of-roundness or temperature compensation. Thin walls and near-edge contact require particular care. Extreme angles and shallow countersinks amplify errors. No claim of certification is implied by engine tests. The user reports the original 1.0.0 build works on their Beam; this revision still needs a device layout check.

Architecture: engine pure JVM math, inspection and ranking; Section vector geometry model; Android Compose dialogs/main screen; Canvas renderer; app-private local preferences. See docs/ENGINEERING.md and docs/VALIDATION.md.

## Open source

Project source is released under the MIT License (LICENSE). Third-party Android, Kotlin, Jetpack and Gradle components retain their own licenses. The main screen and every dialog retain this footer:

Proudly made and released open source by PimaTech.org

## Development signing continuity

The new development key is backed up separately as Pimatech-Ball-Drop-Development-Signing.zip. It is excluded from the open-source archive. Restore its development.keystore and pass its absolute path with `-PpimatechDebugKeystore=/absolute/path/development.keystore` when making future debug builds. The alias/passwords use Android's standard development defaults. This is not a production/Play signing key. Generate and retain separate release credentials when preparing Google Play distribution.
