# Pimatech Ball Drop Calculator — validation and delivery

Date: October 26, 2026. Version 1.0.2, native Android development build.

## Delivered implementation

- Pure Kotlin calculation engine, contact validation, reverse inspection, asymmetric tolerance bands, unit conversion, reference ball grids and operator-maintained available-ball ranking.
- Native Jetpack Compose single main screen with touchable inputs and a decimal keypad; expanded geometry, ball selection, tolerance, settings, help and reset dialogs.
- Proportionally correct vector cross-section of the nominal part and selected ball, with theoretical contact points. Invalid nominal seating suppresses the seated sphere and normal prediction.
- Measured geometry validated against the derived actual major diameter. Missing measurements/tolerances cannot PASS. Invalid measured seating suppresses the measured diameter/deviation.
- Inch/mm display switching preserves canonical unrounded dimensions. Values, measurements, tolerances and inventory persist in app-private local preferences.
- No Internet permission, cloud services, accounts, advertisements, subscriptions or analytics. AndroidX adds one app-private signature permission for internal receiver protection.
- Exact footer on the main screen and every dialog, outside dialog scrolling content: "Proudly made and released open source by PimaTech.org".
- Source released under the included MIT License. No public hosting or repository publication was performed.

## Executed engineering validation

The actual Kotlin engine was compiled and tested independently before graphical implementation using Kotlin 2.0.21 and JUnit 4.13.2. It was then tested again through Gradle as part of the Android build.

Latest engine regression run (1.0.1): 9 test groups; 0 failures; 0 errors; 0 skipped. The four Kotlin engine/test files are byte-identical in 1.0.2. This label-only revision was checked by Android compilation and lint; engine tests were not rerun. The randomized group performs 1,000 seeded geometry cases. Raw JUnit XML and build/lint outputs accompany the source in docs/test-results.

| Test group | Coverage | Outcome |
| --- | --- | --- |
| Reference/independent construction | Midwall optimum; 7/16 ball; perpendicular center-to-wall distance; wall-line tangency; forward height | PASS |
| Strict edges and outside contact | Exact upper/lower boundary tangency; undersized ball; excessive contact diameter; valid B > D | PASS |
| Reverse and units | Forward/reverse round trips over .001°, 1°, 30°, 60°, 82°, 90°, 100°, 120°, 179.999°; inch/mm scaling | PASS with angle-conditioned numeric bounds |
| Invalid inputs | Zero/negative dimensions; invalid angles; D <= d; NaN and infinity | PASS |
| Tolerances and measurement states | Asymmetric bands; exact inclusive limits; outside limits; missing data; impossible readings; incomplete coverage | PASS |
| Measured validity | Validity checked against actual rather than nominal major; measured tangency boundary rejected | PASS |
| Ball selection | Invalid candidates excluded; ideal contact ranks first; fractional 7/16 grid value | PASS |
| Randomized geometry | 1,000 seeded cases checked by independent line-to-center perpendicular distance and reverse recovery | PASS |
| Shallow section | Very shallow wall, exact section contact coordinates, invalid sphere position suppression, zero tolerance | PASS |

Reference case:
D = .4000 in; d = .3605 in; A = 60°.
Optimal ball = .43907487971871034 in.
Optimal contact diameter = .38025 in (50% wall position).
7/16 ball = .4375 in.
Contact diameter = .37888611415569196 in.
Wall position = 46.54712444478975%.
Predicted top-of-ball height = .3098398384862246 in.

At 179.999° the forward/reverse round trip showed approximately 0.00000038 in diameter error from Double rounding amplified by near-singular geometry. This was characterized rather than concealed: the test uses an angle/ULP-based numerical bound, and the app warns for extreme included angles below 2° or above 178°. Normal reference cases use tight numerical tolerances. Such extreme geometry is not a validated physical inspection method.

## APK/build verification

The deliverable is an actual compiled development APK, not only source code. A clean Gradle build runs :engine:test, :app:assembleDebug and :app:lintDebug. APK signing and packaged metadata are independently inspected with Android build tools. Final 1.0.2 outcome: BUILD SUCCESSFUL, exit 0; lint: 0 errors, 1 dependency-version advisory; APK Signature Scheme v2 verification: PASS. The signer matches 1.0.1, so Android can update in place. Raw evidence is in docs/test-results.

Android minimum API 26 (8.0); target/compile API 35. Packaged ABIs include arm64-v8a, armeabi-v7a, x86 and x86_64. This includes the architecture used by conventional modern Android phones and the intended Beam device; it does not establish hardware-specific validation. Development APK uses a debug signing certificate and is not a Play Store or production-signed release.

## Runtime validation limit

The user reports installing 1.0.0 on their Beam and that it works fine. Their supplied screenshot shows the expanded geometry, P marker, measured results and attribution footer on the device. Version 1.0.1 adds the P marker to the main graphic and changes the marker and predicted-height label/value to the same green. This revision has not yet been run on a phone or Beam by the developer; a device layout check is still required. Prior headless emulator attempts did not boot reliably.

## Known limitations / outstanding work

- Treat this as the first shop trial build until real-device and known-part validation are complete.
- Portrait layout is designed to keep all principal values on one screen. Very short landscape displays and large accessibility font settings use a scrolling fallback. Actual device fit and glove usability remain unverified.
- Nominal drawing and contact position are labeled as such; measured contact details are in the expanded geometry dialog.
- Assumes sharp straight coaxial conical surfaces and a perfect sphere. No uncertainty budget, angle calibration, blending radius, edge break, temperature or out-of-roundness correction.
- Signed negative heights are supported mathematically; recessed tops require an appropriate depth measurement setup.
- Reference size grids are not verified commercial availability. Only operator-added My balls are treated as available inventory.
- Display rounding is 5 decimals in inches and 4 in millimeters. Unrounded measured diameter is available in the expanded geometry dialog; acceptance uses unrounded values.
- Last measurement is retained across launches. Clear it before inspecting a different part.
- Original 1.0.0 test signing key was not preserved. Updating to 1.0.1 requires recording inputs and uninstalling the old build first; uninstall clears its local state. The new development key is backed up separately as Pimatech-Ball-Drop-Development-Signing.zip so future debug builds can keep the same identity. Release/Play signing still requires separate retained release credentials.
- An earlier incremental rebuild encountered stale duplicate dex artifacts. A clean rebuild resolved it. If encountered on another development machine, run ./gradlew clean :engine:test :app:assembleDebug :app:lintDebug.

## Recommended next steps

1. Install the APK on the actual phone and Beam; check every input/dialog, footer visibility, unit switching, cancel behavior, restart persistence and screen fit.
2. Enter the reference dimensions above, then a measured height of .3098398384862246 in and tolerances of .001 lower/.001 upper: expected PASS and actual major .4000 in.
3. Trial known countersinks near both tolerance limits with a certified ball and verified hole size/angle. Confirm the measurement setup is capable of the required tolerance.
4. Resolve any device usability issues, then establish retained release signing. Optional later work: operator inventory import/export and a measurement uncertainty/sensitivity report.

## Installation and use

Download Pimatech-Ball-Drop-1.0.2-debug.apk, open it in Android Files, and allow that Files app to install unknown apps if requested. Install and open Pimatech Ball Drop. The app runs offline. Full operator and Android Studio build instructions are in README.md in the source archive.

## Version 1.0.1 interface changes

The P marker (line, end ticks and P letter) now appears on the main-screen graphic as well as the expanded view. It uses #8EE1A8 green, exactly matching the predicted-height label and value. The label includes P. Tolerance colors and calculation engine are unchanged. All four Kotlin engine/test source files were compared byte-for-byte with the prior source archive and match.

The generated APK's packaged version was checked as 1.0.1 / versionCode 2, and its DEX contains the updated predicted-height label. Its signing certificate matches the separately retained development keystore and differs from 1.0.0, confirming the one-time reinstall requirement. No runtime claim is made for this revision until installed and checked on the user's Beam.


## Version 1.0.2 cosmetic update

Requested labels now read C'sink Major Ø and C'sink included angle, with matching entry-dialog titles. These strings were verified in the packaged DEX. APK version is 1.0.2 / versionCode 3. The same application ID and saved development signing certificate are used as 1.0.1, so this version installs as an Update without removing saved local data. Do not uninstall 1.0.1 first.

The user-supplied Beam screenshot confirms the 1.0.1 main-screen green P marker, matching predicted-height text and attribution footer. This revision still needs a visual check of the renamed labels on the Beam.

APK SHA-256: 5c5435a85912c2e7d4f6f3300b816bbfb528ea2624ddc5bba1fa0438e8fb2ab3
