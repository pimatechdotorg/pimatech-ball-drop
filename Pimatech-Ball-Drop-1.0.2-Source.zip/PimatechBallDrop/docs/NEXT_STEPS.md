# Continuation notes

Project: Pimatech Ball Drop Calculator. Native Android; do not substitute a web app.

## Source map
- engine/Geometry.kt: ideal cone/sphere math, contact guards, reverse inspection, tolerance bands, units.
- engine/BallSelection.kt: reference grids and ranking; inventory is user asserted, not supplier verified.
- engine/Section.kt: exact geometric coordinates consumed by the drawing.
- engine/BallDropTest.kt: independent construction, boundary/invalid tests, reverse/unit/tolerance cases and 1,000 seeded randomized checks.
- app/MainActivity.kt: single screen, status, settings/help/expanded section.
- app/Dialogs.kt: custom numeric keypad, atomic tolerance drafts, ball inventory/selection.
- app/GeometryView.kt: actual equal-scale cross-section Canvas; no seated-ball extrapolation when contact invalid.
- app/LocalStore.kt: app-private canonical-inch preferences, persisted measurements and inventory.

## Required future acceptance work

1. User has supplied a Beam screenshot confirming the 1.0.1 main-screen green P marker and matching height text. Install 1.0.2 as an update to check the renamed countersink labels. Continue checking other phone layouts and shop usability.
2. Independently measure a known countersink and certified ball, compare the real reading with the prediction, then trial good/bad parts around tolerance limits.
3. Confirm the assumed minor diameter and included angle are sufficiently accurate for the inspection tolerance. Decide whether a future uncertainty/sensitivity report is needed.
4. Establish retained private release signing for ongoing APK updates. Current development APK is debug-signed. Original 1.0.0 key was lost; moving to 1.0.1 requires one uninstall/reinstall. From 1.0.1 onward restore the separately saved Pimatech-Ball-Drop-Development-Signing.zip and use -PpimatechDebugKeystore=/absolute/path/development.keystore. Do not silently generate another key for future updates.
5. If desired, extend the operator-maintained inventory with export/import and supplier-verified size catalogs. Do not re-label the bundled arithmetic grids as commercially verified stock.

## Preserve these behaviors

B > D is allowed. Strict cone-wall contact is required. Validate measured contact against the derived major diameter. Missing measurement or tolerances cannot PASS. Invalid measured geometry suppresses actual diameter/deviation. All dimensional state stays unrounded internally when display units change. Nominal predictions are clearly labeled. A tolerance band warning never presents theoretical endpoint heights as a usable full-band inspection range.
