# Engineering basis

All engine lengths use one consistent unit (the Android app stores inches); Kotlin Double arithmetic, never display-rounded values. Included angle A must satisfy 0 < A < 180 degrees, and major > minor > 0. Nonfinite inputs are rejected.

## Independent derivation

Take z=0 at the top surface, positive upward. The right cone wall is x = D/2 + z tan(theta), with virtual apex z_a = -D/(2 tan(theta)). A sphere of radius R on axis has perpendicular distance R to this line. Its center is z_c = z_a + R/sin(theta). Its top is P=z_c+R. Therefore P=R(1+csc(theta))-D/(2 tan(theta)). Rearranging gives D=2 tan(theta)[R(1+csc(theta))-P].

A perpendicular radius to the right wall has horizontal projection R cos(theta) and downward projection R sin(theta). Hence contact diameter is B cos(theta), and contact elevation is z_c-R sin(theta). This also satisfies the wall line equation. Straight wall distance is linear in diameter, so the midpoint diameter is (D+d)/2 and Boptimal=(D+d)/(2 cos(theta)).

The implementation evaluates the equivalent forward expression B/2+(B-D cos(theta))/(2 sin(theta)), and reverse expression [B(1+sin(theta))-2P sin(theta)]/cos(theta). These avoid tan/csc products and retain Double precision. Near-degenerate angles still magnify measurement uncertainty; mathematical acceptance does not establish measurement capability.

## Boundary policy

Contact must lie strictly between minor and major intersections. A relative 1e-12 numerical guard excludes unresolved contact at either boundary; it is not a manufacturing tolerance or a recommended physical edge clearance. Zero and negative ball diameters, nonfinite numbers, invalid angles, nonpositive hole dimensions, and unresolved wall width are invalid. B > D alone is allowed.

Nominal prediction and measured inspection are separate. Reverse inspection validates the derived major diameter with the assumed minor diameter. Invalid measured geometry suppresses the derived diameter and deviation. Tolerances are nonnegative lower/upper offsets, inclusive at diameter limits with a 1e-12 relative arithmetic guard. No measurement or no tolerance means NOT EVALUATED. A valid measured contact can PASS even when the chosen ball does not cover the entire tolerance band; that condition is explicitly warned.

The cone is ideal, coaxial, circular and sharp edged. Hole and countersink out-of-roundness, bellmouth, edge breaks, blending radii, contamination, ball uncertainty, measuring force, temperature and angle error are not modeled. Negative P is mathematically permitted for a recessed ball; use a signed depth measurement and suitable instrumentation. A top-surface height instrument cannot measure a recessed ball directly.

## Reference

D=.4000 in; d=.3605 in; A=60 degrees.
Boptimal=.43907487971871034 in; Dcontact=.38025 in.
7/16-inch ball: B=.4375 in; contact=.37888611415569196 in;
P=.3098398384862246 in; contact position about 46.5471%.

Reference fractional and metric lists are arithmetic size grids, not a supplier catalog. They do not assert commercial availability, ball grade, certification, or actual shop inventory. Only balls explicitly added by the operator are called available.
