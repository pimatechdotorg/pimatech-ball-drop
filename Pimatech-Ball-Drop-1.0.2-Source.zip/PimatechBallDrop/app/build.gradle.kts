plugins {
    id("com.android.application")
    kotlin("android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.pimatech.balldrop"
    compileSdk = 35
    defaultConfig { applicationId = "com.pimatech.balldrop"; minSdk = 26; targetSdk = 35; versionCode = 3; versionName = "1.0.2" }
    providers.gradleProperty("pimatechDebugKeystore").orNull?.let {
        signingConfigs.getByName("debug").storeFile = file(it)
    }
    buildFeatures { compose = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(project(":engine"))
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
