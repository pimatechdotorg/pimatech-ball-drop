package com.pimatech.balldrop

import android.content.Context
import com.pimatech.balldrop.engine.*

/** Atomic single preference record for geometry; Android app-private and offline. */
data class ShopState(
    val geometry: Geometry=Geometry(.4000,.3605,60.0,.4375),
    val measurement: Double?=null,
    val tolerance: Tolerance?=null,
    val unit: LengthUnit=LengthUnit.INCH,
    val available: List<Double> = emptyList()
)
class LocalStore(context: Context) {
    private val prefs=context.getSharedPreferences("inspection-v1",Context.MODE_PRIVATE)
    fun load(): ShopState = runCatching {
        val defaults=ShopState()
        fun value(k:String,d:Double)=prefs.getString(k,null)?.toDoubleOrNull()?.takeIf{it.isFinite()} ?: d
        fun optional(k:String)=prefs.getString(k,null)?.toDoubleOrNull()?.takeIf{it.isFinite()}
        val lower=optional("lower"); val upper=optional("upper")
        ShopState(Geometry(value("major",defaults.geometry.major),value("minor",defaults.geometry.minor),value("angle",60.0),value("ball",.4375)),optional("measurement"),if(lower!=null && upper!=null) Tolerance(lower,upper) else null,LengthUnit.valueOf(prefs.getString("unit","INCH") ?: "INCH"),prefs.getString("available","")!!.split(';').mapNotNull{it.toDoubleOrNull()?.takeIf{v->v.isFinite() && v>0}})
    }.getOrDefault(ShopState())
    fun save(s:ShopState) {
        prefs.edit().putString("major",s.geometry.major.toString()).putString("minor",s.geometry.minor.toString()).putString("angle",s.geometry.angle.toString()).putString("ball",s.geometry.ball.toString()).putString("measurement",s.measurement?.toString()).putString("lower",s.tolerance?.lower?.toString()).putString("upper",s.tolerance?.upper?.toString()).putString("unit",s.unit.name).putString("available",s.available.joinToString(";")).apply()
    }
}
