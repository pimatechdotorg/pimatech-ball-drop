package com.pimatech.balldrop

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pimatech.balldrop.engine.*
import java.util.Locale

val Ink=Color(0xFF0B1119)
val Panel=Color(0xFF172330)
val Cyan=Color(0xFF66D7EF)
val Muted=Color(0xFFB3C2D1)
val Good=Color(0xFF8EE1A8)
val Warn=Color(0xFFFFCA75)
val Bad=Color(0xFFFF8F91)
fun format(value:Double?,unit:LengthUnit):String = if(value==null || !value.isFinite()) "—" else String.format(Locale.US,"%.${unit.decimals}f",unit.display(value))
fun dimension(value:Double?,unit:LengthUnit)=format(value,unit)+if(value==null) "" else " ${unit.label}"
data class Entry(val title:String,val initial:Double?,val unit:String,val nullable:Boolean=false,val signed:Boolean=false,val commit:(Double?)->Unit)

class MainActivity:ComponentActivity() {
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        val store=LocalStore(this)
        setContent {
            MaterialTheme(colorScheme=darkColorScheme(primary=Cyan,background=Ink,surface=Panel,onSurface=Color.White,onBackground=Color.White,secondary=Good,error=Bad)) {
                var state by remember { mutableStateOf(store.load()) }
                fun change(next:ShopState) { state=next; store.save(next) }
                Calculator(state,::change)
            }
        }
    }
}

@Composable fun Calculator(s:ShopState, change:(ShopState)->Unit) {
    var popup by remember { mutableStateOf<String?>(null) }
    var entry by remember { mutableStateOf<Entry?>(null) }
    val g=s.geometry; val u=s.unit
    val cone=runCatching { BallDrop.cone(g) }.getOrNull()
    val nominal=runCatching { BallDrop.contact(g) }.getOrNull()
    val inspection=BallDrop.inspect(g,s.measurement,s.tolerance)
    val band=s.tolerance?.let { runCatching { BallDrop.band(g,it) }.getOrNull() }
    val statusColor=when(inspection.status) { InspectionStatus.PASS->Good; InspectionStatus.FAIL,InspectionStatus.INVALID->Bad; else->Warn }
    fun edit(title:String,value:Double?,angle:Boolean=false,optional:Boolean=false,signed:Boolean=false,commit:(Double?)->Unit) {
        entry=Entry(title,if(angle) value else value?.let(u::display),if(angle) "degrees" else u.label,optional,signed) { v->commit(if(angle) v else v?.let(u::canonical)) }
    }
    Surface(color=Ink,modifier=Modifier.fillMaxSize()) {
        BoxWithConstraints(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            // Normal portrait fits without scrolling. Short landscape/large-font screens get an accessible fallback.
            val fallback=maxHeight<550.dp || androidx.compose.ui.platform.LocalDensity.current.fontScale>1.3f
            val body=if(fallback) Modifier.verticalScroll(rememberScrollState()) else Modifier
            Column(Modifier.fillMaxSize().then(body).padding(horizontal=12.dp,vertical=6.dp),verticalArrangement=Arrangement.spacedBy(3.dp)) {
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("PIMATECH",color=Cyan,fontSize=12.sp,lineHeight=12.sp,fontWeight=FontWeight.Bold,letterSpacing=2.sp); Text("BALL DROP",fontSize=18.sp,lineHeight=20.sp,fontWeight=FontWeight.Bold) }
                    TextButton(onClick={popup="settings"}) { Text(u.label.uppercase(),fontWeight=FontWeight.Bold) }
                }
                Surface(shape=RoundedCornerShape(12.dp),color=Panel,modifier=Modifier.fillMaxWidth().then(if(fallback) Modifier.height(190.dp) else Modifier.weight(1f)).clickable{popup="geometry"}) {
                    Column(Modifier.padding(8.dp)) {
                        Text("NOMINAL SECTION  ·  TAP TO EXPAND",fontSize=10.sp,lineHeight=12.sp,color=Muted)
                        GeometryView(g,u,Modifier.fillMaxWidth().weight(1f))
                    }
                }
                InputRow {
                    ValueButton("C'sink Major Ø",dimension(g.major,u),Modifier.weight(1f)) { edit("C'sink Major Ø",g.major){change(s.copy(geometry=g.copy(major=it!!))) } }
                    ValueButton("Hole / minor Ø",dimension(g.minor,u),Modifier.weight(1f)) { edit("Hole / minor diameter",g.minor){change(s.copy(geometry=g.copy(minor=it!!))) } }
                }
                InputRow {
                    ValueButton("C'sink included angle",String.format(Locale.US,"%.3f°",g.angle),Modifier.weight(1f)) { edit("C'sink included angle",g.angle,angle=true){change(s.copy(geometry=g.copy(angle=it!!))) } }
                    ValueButton("Gauge ball Ø",dimension(g.ball,u),Modifier.weight(1f)) { edit("Actual gauge ball diameter",g.ball){change(s.copy(geometry=g.copy(ball=it!!))) } }
                }
                ValueButton("Measured height P  ·  signed from surface",dimension(s.measurement,u),Modifier.fillMaxWidth()) { edit("Measured top of ball height",s.measurement,optional=true,signed=true){change(s.copy(measurement=it))} }
                InputRow {
                    ResultCell("OPTIMAL BALL Ø",dimension(cone?.optimalBall,u),Cyan,Modifier.weight(1f))
                    ResultCell("CONTACT Ø · NOMINAL",dimension(nominal?.diameter,u),Color.White,Modifier.weight(1f))
                }
                InputRow {
                    ResultCell("WALL POSITION · NOMINAL",nominal?.let{String.format(Locale.US,"%.2f%%",it.percent)} ?: "INVALID",if(nominal==null) Bad else Color.White,Modifier.weight(1f))
                    ResultCell("PREDICTED HEIGHT · P",dimension(nominal?.height,u),Good,Modifier.weight(1f),labelColor=Good)
                }
                InputRow {
                    ResultCell("ACTUAL MAJOR Ø",dimension(inspection.actualMajor,u),Cyan,Modifier.weight(1f))
                    ResultCell("Δ FROM NOMINAL",inspection.delta?.let{(if(it>0) "+" else "")+dimension(it,u)} ?: "—",statusColor,Modifier.weight(1f))
                }
                Surface(color=statusColor.copy(alpha=.10f),shape=RoundedCornerShape(8.dp),modifier=Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(horizontal=10.dp,vertical=5.dp)) {
                        Text(inspection.status.name.replace('_',' '),color=statusColor,fontWeight=FontWeight.Bold,fontSize=16.sp,lineHeight=18.sp)
                        val warning=when {
                            inspection.status==InspectionStatus.INVALID -> inspection.reason
                            g.angle<2 || g.angle>178 -> "Extreme angle: measurement errors strongly amplified"
                            band!=null && !band.validThroughout -> "Ball cannot inspect the full tolerance band"
                            else -> inspection.reason
                        }
                        Text(warning,color=Muted,fontSize=11.sp,lineHeight=13.sp,maxLines=2,overflow=TextOverflow.Ellipsis)
                    }
                }
                InputRow {
                    ActionButton("Optimal Ball",Modifier.weight(1f)){popup="balls"}
                    ActionButton("Tolerances",Modifier.weight(1f)){popup="tolerances"}
                    ActionButton("Settings",Modifier.weight(1f)){popup="settings"}
                    ActionButton("Reset",Modifier.weight(1f)){popup="reset"}
                }
                Attribution()
            }
        }
    }
    when(popup) {
        "geometry" -> ShopDialog("Geometry · nominal",{popup=null}) {
            GeometryView(g,u,Modifier.fillMaxWidth().height(300.dp),expanded=true)
            Text("Nominal: ${dimension(g.major,u)} major / ${dimension(g.minor,u)} minor; ${g.angle}° included",color=Muted)
            Text("Ball: ${dimension(g.ball,u)}; theoretical contact: ${dimension(nominal?.diameter,u)}")
            Text("Nominal wall position: ${nominal?.let{String.format(Locale.US,"%.3f%%",it.percent)} ?: "INVALID"}")
            inspection.actualContact?.let { Text("Measured wall position: ${String.format(Locale.US,"%.3f%%",it.percent)}; measured contact Ø: ${dimension(it.diameter,u)}") }
            inspection.actualMajor?.let { Text("Unrounded measured major: ${u.display(it)} ${u.label}",fontSize=12.sp,color=Muted) }
            Text("Green dots: valid theoretical contact. Red: unsuitable ball. Ball diameter may exceed the opening. Drawing uses equal horizontal and vertical scales.",fontSize=12.sp,color=Muted)
        }
        "balls" -> BallDialog(s,{popup=null},{change(s.copy(geometry=g.copy(ball=it)))},{change(s.copy(available=it))},{ edit("Add available ball diameter",null){b->if(b!=null && b>0) change(s.copy(available=(s.available+b).distinct().sorted()))} })
        "tolerances" -> ToleranceDialog(s,{popup=null}){change(s.copy(tolerance=it));popup=null}
        "settings" -> ShopDialog("Settings",{popup=null}) {
            Text("Display units · geometry is preserved")
            InputRow { LengthUnit.entries.forEach { unit->OutlinedButton(onClick={change(s.copy(unit=unit))},modifier=Modifier.weight(1f)){Text(if(u==unit) "✓ ${unit.label}" else unit.label)} } }
            Text("Inches: 5 decimals · millimeters: 4 decimals\nCalculations retain full Double precision.",color=Muted)
            Text("Values save locally, including measured height. Clear the height before inspecting a new part. No network access or data collection.",fontSize=13.sp)
            OutlinedButton(onClick={popup="help"},modifier=Modifier.fillMaxWidth()){Text("Help & engineering")}
            Text("Version 1.0.2 · Native Android",fontSize=12.sp,color=Muted)
        }
        "help" -> ShopDialog("Operator & engineering",{popup=null}) {
            Text("Enter D, d, included angle A, and the certified ball diameter B. Optimal Ball finds midpoint wall contact; choose a ball you actually have. Enter measured top-of-ball height P and explicit lower/upper tolerance offsets.")
            Text("PASS/FAIL require valid measured contact and tolerances. INVALID suppresses the measured result. Nominal results are setup predictions only. A full-band warning means this ball is unsuitable for some otherwise acceptable parts.")
            Text("Contact Ø = B cos(A/2)\nValid: d < contact Ø < D\nOptimal B = (D+d) / [2 cos(A/2)]\nP = B/2 [1+csc(A/2)] − D/[2 tan(A/2)]")
            Text("Contact position: 0% bottom, 50% midpoint, 100% top. Boundary contact is invalid. Negative P denotes a recessed ball; use a suitable signed depth setup.")
            Text("Ideal sharp, coaxial cone and perfect sphere only. Confirm hole size, angle, clean seating and measurement uncertainty. Blended edges, out-of-roundness and temperature are not modeled. Near 0°/180° or very shallow geometry is sensitive to error.")
            Text("Tap drawing for detail. Cancel or Back keeps existing values. Reference size grids do not assert availability; My balls is operator-maintained inventory.",color=Muted)
        }
        "reset" -> ShopDialog("Reset inspection?",{popup=null}) {
            Text("Restore the .4000 / .3605 / 60° / 7⁄16 example and clear measurement and tolerances. Keep display units and My balls.")
            InputRow {
                OutlinedButton(onClick={popup=null},modifier=Modifier.weight(1f)){Text("Cancel")}
                Button(onClick={change(ShopState(unit=u,available=s.available));popup=null},modifier=Modifier.weight(1f)){Text("Reset")}
            }
        }
    }
    entry?.let { e-> NumericDialog(e,{entry=null}){v->e.commit(v);entry=null} }
}

@Composable fun InputRow(content:@Composable RowScope.()->Unit) { Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp),content=content) }
@Composable fun ValueButton(label:String,value:String,modifier:Modifier=Modifier,onClick:()->Unit) {
    Surface(onClick=onClick,color=Panel,shape=RoundedCornerShape(8.dp),modifier=modifier.heightIn(min=48.dp)) {
        Column(Modifier.padding(horizontal=10.dp,vertical=4.dp)) { Text(label,fontSize=10.sp,lineHeight=12.sp,color=Muted,maxLines=1,overflow=TextOverflow.Ellipsis); Text(value,fontSize=18.sp,lineHeight=22.sp,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis) }
    }
}
@Composable fun ResultCell(label:String,value:String,color:Color,modifier:Modifier,labelColor:Color=Muted) {
    Column(modifier.padding(horizontal=4.dp,vertical=1.dp)) { Text(label,color=labelColor,fontSize=9.sp,lineHeight=10.sp,maxLines=1); Text(value,color=color,fontSize=16.sp,lineHeight=20.sp,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis) }
}
@Composable fun ActionButton(title:String,modifier:Modifier,onClick:()->Unit) { OutlinedButton(onClick=onClick,modifier=modifier.heightIn(min=48.dp),shape=RoundedCornerShape(8.dp),contentPadding=PaddingValues(horizontal=8.dp,vertical=4.dp)){Text(title,fontSize=10.sp,lineHeight=12.sp,maxLines=2)} }

@Composable fun Attribution() {
    Text("Proudly made and released open source by PimaTech.org",color=Muted,fontSize=10.sp,lineHeight=12.sp,textAlign=androidx.compose.ui.text.style.TextAlign.Center,modifier=Modifier.fillMaxWidth().padding(top=4.dp,bottom=2.dp))
}
