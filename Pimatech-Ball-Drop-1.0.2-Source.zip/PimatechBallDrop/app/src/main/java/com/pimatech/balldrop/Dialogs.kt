package com.pimatech.balldrop

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.pimatech.balldrop.engine.*
import java.util.Locale

@Composable fun ShopDialog(title:String,onDismiss:()->Unit,content:@Composable ColumnScope.()->Unit) {
    Dialog(onDismissRequest=onDismiss) {
        Surface(color=Panel,shape=RoundedCornerShape(16.dp)) {
            Column(Modifier.fillMaxWidth().heightIn(max=680.dp).padding(16.dp)) {
                Text(title,fontSize=21.sp,fontWeight=FontWeight.Bold,color=Cyan)
                Column(Modifier.weight(1f,fill=false).verticalScroll(rememberScrollState()).padding(top=12.dp),verticalArrangement=Arrangement.spacedBy(12.dp),content=content)
                TextButton(onClick=onDismiss,modifier=Modifier.align(Alignment.End)){Text("Close")}
                Attribution()
            }
        }
    }
}

@Composable fun NumericDialog(entry:Entry,onDismiss:()->Unit,onConfirm:(Double?)->Unit) {
    var text by remember(entry) { mutableStateOf(entry.initial?.let{java.math.BigDecimal.valueOf(it).stripTrailingZeros().toPlainString()} ?: "") }
    var replace by remember(entry) { mutableStateOf(true) }
    val parsed=text.toDoubleOrNull()?.takeIf { it.isFinite() }
    val canSave=parsed!=null || (entry.nullable && text.isBlank())
    Dialog(onDismissRequest=onDismiss) {
        Surface(color=Panel,shape=RoundedCornerShape(16.dp)) {
            Column(Modifier.heightIn(max=680.dp).padding(16.dp)) {
              Column(Modifier.weight(1f,fill=false).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text(entry.title,fontSize=19.sp,fontWeight=FontWeight.Bold)
                Text(entry.unit,color=Muted)
                Surface(color=Ink,shape=RoundedCornerShape(8.dp),modifier=Modifier.fillMaxWidth()) {
                    Text(text.ifEmpty{"—"},color=if(replace) Cyan else androidx.compose.ui.graphics.Color.White,fontSize=28.sp,modifier=Modifier.padding(12.dp),maxLines=2)
                }
                listOf(listOf("7","8","9"),listOf("4","5","6"),listOf("1","2","3"),listOf(".","0","⌫")).forEach { row ->
                    InputRow { row.forEach { key ->
                        FilledTonalButton(onClick={
                            if(key=="⌫") { text=if(replace) "" else text.dropLast(1);replace=false }
                            else { if(replace){text="";replace=false}; if(text.length<24 && (key!="." || !text.contains('.'))) text+=if(key=="." && (text.isEmpty() || text=="-")) "0." else key }
                        },modifier=Modifier.weight(1f).height(48.dp),shape=RoundedCornerShape(8.dp)) { Text(key,fontSize=22.sp) }
                    } }
                }
                InputRow {
                    TextButton(onClick={text="";replace=false},modifier=Modifier.weight(1f)){Text("Clear")}
                    if(entry.signed) TextButton(onClick={text=if(text.startsWith('-')) text.drop(1) else "-$text";replace=false},modifier=Modifier.weight(1f)){Text("±")}
                }
                if(!canSave) Text("Enter a finite decimal number",color=Warn,fontSize=12.sp)
                if(entry.nullable) Text("Clear + Save removes the measurement.",color=Muted,fontSize=12.sp)
                InputRow {
                    OutlinedButton(onClick=onDismiss,modifier=Modifier.weight(1f)){Text("Cancel")}
                    Button(onClick={onConfirm(parsed)},enabled=canSave,modifier=Modifier.weight(1f)){Text("Save")}
                }
              }
              Attribution()
            }
        }
    }
}

@Composable fun ToleranceDialog(s:ShopState,onDismiss:()->Unit,onSave:(Tolerance?)->Unit) {
    var lower by remember { mutableStateOf(s.tolerance?.lower) }
    var upper by remember { mutableStateOf(s.tolerance?.upper) }
    var entry by remember { mutableStateOf<Entry?>(null) }
    val unit=s.unit
    val draft=if(lower!=null && upper!=null) Tolerance(lower!!,upper!!) else null
    val band=draft?.let { runCatching{BallDrop.band(s.geometry,it)}.getOrNull() }
    ShopDialog("Inspection tolerances",onDismiss) {
        Text("Nominal major: ${dimension(s.geometry.major,unit)}")
        Text("Enter positive offsets: nominal − lower / + upper. Zero must be entered explicitly.",fontSize=13.sp,color=Muted)
        ValueButton("Lower offset (−)",dimension(lower,unit),Modifier.fillMaxWidth()) {
            entry=Entry("Lower tolerance offset",lower?.let(unit::display),unit.label) { v->lower=v?.let(unit::canonical) }
        }
        ValueButton("Upper offset (+)",dimension(upper,unit),Modifier.fillMaxWidth()) {
            entry=Entry("Upper tolerance offset",upper?.let(unit::display),unit.label) { v->upper=v?.let(unit::canonical) }
        }
        if(band!=null) {
            Text("Diameter limits\n${dimension(band.lowDiameter,unit)} to ${dimension(band.highDiameter,unit)}")
            if(band.validThroughout) {
                Text("Acceptable ball height\n${dimension(band.minimumHeight,unit)} to ${dimension(band.maximumHeight,unit)}",color=Good)
                Text("Ball contact remains valid throughout the tolerance band.",color=Good,fontSize=13.sp)
            } else {
                Text("Ball does NOT maintain conical contact over the full band.",color=Bad,fontWeight=FontWeight.Bold)
                Text("Theoretical endpoint heights: ${dimension(band.minimumHeight,unit)} to ${dimension(band.maximumHeight,unit)}. These are NOT a usable full-band acceptance range.",color=Warn,fontSize=13.sp)
            }
        } else Text(if(draft==null) "Enter both offsets to enable inspection." else "Invalid tolerance limits or ball geometry.",color=Warn)
        Text("Larger countersink diameters produce lower ball-height readings. Limits are inclusive; tangency boundaries remain invalid.",color=Muted,fontSize=12.sp)
        InputRow {
            OutlinedButton(onClick={onSave(null)},modifier=Modifier.weight(1f)){Text("Remove")}
            Button(onClick={onSave(draft)},enabled=band!=null,modifier=Modifier.weight(1f)){Text("Save")}
        }
        Text("Close/Back cancels tolerance edits.",color=Muted,fontSize=12.sp)
    }
    entry?.let { e->NumericDialog(e,{entry=null}){v->e.commit(v);entry=null} }
}

@Composable fun BallDialog(s:ShopState,onDismiss:()->Unit,onSelect:(Double)->Unit,onInventory:(List<Double>)->Unit,onAdd:()->Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val g=s.geometry; val unit=s.unit
    val cone=runCatching{BallDrop.cone(g)}.getOrNull()
    val candidates=when(tab) { 0->s.available.map{BallSize(dimension(it,unit),it)}; 1->BallSelection.fractional; else->BallSelection.metric }
    val ranked=BallSelection.rank(g,candidates)
    ShopDialog("Optimal & available balls",onDismiss) {
        Text("Mathematical optimum",color=Muted)
        Text(dimension(cone?.optimalBall,unit),fontSize=27.sp,color=Cyan,fontWeight=FontWeight.Bold)
        if(cone!=null) {
            Text("Strict geometric limits\n${dimension(cone.minimumBall,unit)} < B < ${dimension(cone.maximumBall,unit)}",fontSize=13.sp)
            Text("Boundary limits are not recommended ball sizes. Ideal wall contact is 50%.",color=Muted,fontSize=12.sp)
        }
        OutlinedButton(onClick=onAdd,modifier=Modifier.fillMaxWidth()){Text("Add a ball I have · manual entry")}
        InputRow {
            listOf("My balls","Inch grid","mm grid").forEachIndexed { i,label->
                TextButton(onClick={tab=i},modifier=Modifier.weight(1f),contentPadding=PaddingValues(0.dp)){Text(if(tab==i) "● $label" else label,fontSize=12.sp)}
            }
        }
        Text(if(tab==0) "Your inventory, ranked nearest 50% contact." else "Reference sizes only — availability unverified. Ranked by valid contact, not supplier availability.",color=Warn,fontSize=12.sp)
        if(ranked.isEmpty()) Text(if(tab==0) "No suitable balls in your inventory. Add measured diameters or inspect the reference grids." else "No valid sizes in this reference grid.",color=Muted)
        ranked.forEachIndexed { i,r ->
            Surface(color=Ink,shape=RoundedCornerShape(8.dp),modifier=Modifier.fillMaxWidth()) {
                Column(Modifier.padding(8.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text((if(i==0) "★ " else "")+r.size.label,color=if(i==0) Cyan else androidx.compose.ui.graphics.Color.White,fontWeight=FontWeight.Bold)
                            Text(String.format(Locale.US,"%.2f%% contact",r.contactPercent),fontSize=12.sp,color=Muted)
                        }
                        TextButton(onClick={onSelect(r.size.inches);onDismiss()}){Text("Use")}
                    }
                    val owned=s.available.any { kotlin.math.abs(it-r.size.inches)<1e-12 }
                    TextButton(onClick={onInventory(if(owned) s.available.filterNot{kotlin.math.abs(it-r.size.inches)<1e-12} else (s.available+r.size.inches).sorted())},contentPadding=PaddingValues(0.dp)) { Text(if(owned) "Remove from My balls" else "+ I have this ball",fontSize=12.sp) }
                }
            }
        }
        if(tab==0 && s.available.size>ranked.size) {
            Text("${s.available.size-ranked.size} inventory ball(s) excluded: no valid nominal conical contact.",color=Bad,fontSize=12.sp)
            s.available.filterNot { b->ranked.any { it.size.inches==b } }.forEach { b->
                TextButton(onClick={onInventory(s.available-b)}){Text("Remove unsuitable ${dimension(b,unit)}",color=Bad)}
            }
        }
    }
}
