package com.pimatech.balldrop

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import com.pimatech.balldrop.engine.*
import kotlin.math.*

@Composable fun GeometryView(g:Geometry,unit:LengthUnit,modifier:Modifier,expanded:Boolean=false) {
    val section=runCatching{Section.of(g)}.getOrNull()
    val labelSize=with(LocalDensity.current) { (if(expanded) 13 else 10).sp.toPx() }
    Canvas(modifier) {
        val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=android.graphics.Color.rgb(179,194,209);textSize=labelSize }
        fun label(text:String,x:Float,y:Float,color:Color=Muted) { paint.color=color.toArgb();drawContext.canvas.nativeCanvas.drawText(text,x,y,paint) }
        if(section==null) {label("INVALID GEOMETRY",12f,size.height/2,Bad);return@Canvas}
        val a=section.majorRadius;val b=section.minorRadius;val depth=section.depth;val r=section.ballRadius
        val valid=section.ballCenterZ!=null
        val xSpan=max(a*1.6,if(valid) r*1.25 else a*1.6)
        val bottom=max(depth+max(a*.32,depth*.08),if(valid) r-section.ballCenterZ!!+a*.08 else 0.0)
        val top=max(a*.28,if(valid) section.ballCenterZ!!+r else a*.28)
        val marginX=12.dp.toPx();val marginY=labelSize*1.7f
        val scale=min((size.width-2*marginX)/(2*xSpan),(size.height-2*marginY)/(top+bottom)).toFloat()
        if(!scale.isFinite() || scale<=0) return@Canvas
        val cx=size.width/2
        val zeroY=marginY+(top*scale).toFloat()
        fun p(x:Double,z:Double)=Offset(cx+(x*scale).toFloat(),zeroY-(z*scale).toFloat())
        val wall=if(valid) Color(0xFFCCD9E8) else Bad
        val stroke=if(expanded) 2.5.dp.toPx() else 1.7.dp.toPx()
        clipRect {
            for(sign in listOf(-1,1)) {
                val fill=Path().apply {
                    moveTo(p(sign*xSpan,0.0).x,p(sign*xSpan,0.0).y)
                    lineTo(p(sign*a,0.0).x,p(sign*a,0.0).y)
                    lineTo(p(sign*b,-depth).x,p(sign*b,-depth).y)
                    lineTo(p(sign*b,-bottom).x,p(sign*b,-bottom).y)
                    lineTo(p(sign*xSpan,-bottom).x,p(sign*xSpan,-bottom).y);close()
                }
                drawPath(fill,Color(0xFF324455))
                drawLine(wall,p(sign*xSpan,0.0),p(sign*a,0.0),stroke)
                drawLine(wall,p(sign*a,0.0),p(sign*b,-depth),stroke)
                drawLine(wall,p(sign*b,-depth),p(sign*b,-bottom),stroke)
            }
            drawLine(Muted.copy(alpha=.6f),p(0.0,top),p(0.0,-bottom),1.dp.toPx(),pathEffect=PathEffect.dashPathEffect(floatArrayOf(8f,6f)))
            if(valid) {
                val center=section.ballCenterZ!!
                drawCircle(Cyan.copy(alpha=.17f),radius=(r*scale).toFloat(),center=p(0.0,center))
                drawCircle(Cyan,radius=(r*scale).toFloat(),center=p(0.0,center),style=Stroke(stroke))
                for(sign in listOf(-1,1)) {
                    drawLine(Cyan.copy(alpha=.45f),p(0.0,center),p(sign*section.contactRadius!!,section.contactZ!!),1.dp.toPx())
                    drawCircle(Good,3.2.dp.toPx(),p(sign*section.contactRadius!!,section.contactZ!!))
                }
                // Surface-to-ball-top dimension on both the compact and expanded views.
                run {
                    val x=max(a,r)*1.13
                    val pt=center+r
                    drawLine(Good,p(x,0.0),p(x,pt),1.dp.toPx())
                    for(z in listOf(0.0,pt)) drawLine(Good,p(x-a*.04,z),p(x+a*.04,z),1.dp.toPx())
                    label("P",p(x,pt/2).x+5f,p(x,pt/2).y,Good)
                }
            }
        }
        // Dimension labels remain readable while the section retains exact proportions.
        label("D ${dimension(g.major,unit)}",4f,labelSize)
        val angleText="A ${String.format(java.util.Locale.US,"%.2f°",g.angle)}"
        label(angleText,size.width-paint.measureText(angleText)-4f,labelSize)
        label("d ${dimension(g.minor,unit)}",4f,size.height-3f)
        val ballText="B ${dimension(g.ball,unit)}"
        label(ballText,size.width-paint.measureText(ballText)-4f,size.height-3f,if(valid) Cyan else Bad)
        if(!valid) {
            val msg="NO VALID CONICAL SEAT"
            label(msg,(size.width-paint.measureText(msg))/2,max(labelSize*2.4f,size.height*.4f),Bad)
        }
    }
}
